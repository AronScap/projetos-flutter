package io.designcode.designcode

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
